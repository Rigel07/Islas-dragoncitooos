package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.item.AmuletItem;
import com.isladragoncitos.item.DragonCompassItem;
import com.isladragoncitos.item.DragonScaleItem;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, IslaDragoncitosMod.MODID);

    public static final RegistryObject<Item> PINK_DRAGON_SCALE = scale("pink_dragon_scale", 0);
    public static final RegistryObject<Item> GREEN_DRAGON_SCALE = scale("green_dragon_scale", 1);
    public static final RegistryObject<Item> BLUE_DRAGON_SCALE = scale("blue_dragon_scale", 2);
    public static final RegistryObject<Item> RED_DRAGON_SCALE = scale("red_dragon_scale", 3);

    public static final RegistryObject<Item> PINK_AMULET = ITEMS.register("pink_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC),
                    MobEffects.REGENERATION, MobEffects.LUCK, "tooltip.isladragoncitos.amulet.pink"));
    public static final RegistryObject<Item> GREEN_AMULET = ITEMS.register("green_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC),
                    MobEffects.MOVEMENT_SPEED, MobEffects.JUMP, "tooltip.isladragoncitos.amulet.green"));
    public static final RegistryObject<Item> BLUE_AMULET = ITEMS.register("blue_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC),
                    MobEffects.WATER_BREATHING, MobEffects.DOLPHINS_GRACE, "tooltip.isladragoncitos.amulet.blue"));
    public static final RegistryObject<Item> RED_AMULET = ITEMS.register("red_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC),
                    MobEffects.FIRE_RESISTANCE, MobEffects.DIG_SPEED, "tooltip.isladragoncitos.amulet.red"));

    public static final RegistryObject<Item> DRAGON_COMPASS = ITEMS.register("dragon_compass",
            () -> new DragonCompassItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> PINK_SCALE_BLOCK = blockItem("pink_scale_block", ModBlocks.PINK_SCALE_BLOCK);
    public static final RegistryObject<Item> GREEN_SCALE_BLOCK = blockItem("green_scale_block", ModBlocks.GREEN_SCALE_BLOCK);
    public static final RegistryObject<Item> BLUE_SCALE_BLOCK = blockItem("blue_scale_block", ModBlocks.BLUE_SCALE_BLOCK);
    public static final RegistryObject<Item> RED_SCALE_BLOCK = blockItem("red_scale_block", ModBlocks.RED_SCALE_BLOCK);

    public static final RegistryObject<Item> DRAGONCITO_SPAWN_EGG = ITEMS.register("dragoncito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.DRAGONCITO, 0xFF8FBF, 0x66CCFF, new Item.Properties()));

    public static final RegistryObject<Item> DRAGON_STATUE = ITEMS.register("dragon_statue",
            () -> new BlockItem(ModBlocks.DRAGON_STATUE.get(), new Item.Properties().rarity(Rarity.EPIC)));

    private ModItems() {}

    private static RegistryObject<Item> scale(String name, int variant) {
        return ITEMS.register(name, () -> new DragonScaleItem(variant, new Item.Properties().rarity(Rarity.RARE)));
    }

    private static RegistryObject<Item> blockItem(String name, RegistryObject<net.minecraft.world.level.block.Block> block) {
        return ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    /** Escama del color indicado (0 rosa, 1 verde, 2 azul, 3 rojo). */
    public static Item scaleFor(int variant) {
        switch (variant & 3) {
            case 1:
                return GREEN_DRAGON_SCALE.get();
            case 2:
                return BLUE_DRAGON_SCALE.get();
            case 3:
                return RED_DRAGON_SCALE.get();
            default:
                return PINK_DRAGON_SCALE.get();
        }
    }
}
