package com.isladragoncitos.worldgen;

import com.isladragoncitos.block.IslandStatueBlock;
import com.isladragoncitos.block.IslandStatueBlockEntity;
import com.isladragoncitos.entity.DragoncitoEntity;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.material.Fluids;

/** La isla flotante completa. Cada chunk coloca su parte a partir de la geometria determinista de IslaShape. */
public class IslaPiece extends StructurePiece {
    /** Version de la generacion: 1 = mod 1.0 (islas clasicas), 2 = islas variadas. */
    public static final int CURRENT_VERSION = 2;

    private static final ResourceLocation CHEST_LOOT = new ResourceLocation("isladragoncitos", "chests/isla_cofre");

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState WATER = Blocks.WATER.defaultBlockState();
    private static final BlockState LAVA = Blocks.LAVA.defaultBlockState();
    private static final BlockState FLOW_TOP = Blocks.WATER.defaultBlockState().setValue(BlockStateProperties.LEVEL, 1);
    private static final BlockState FALLING_WATER = Blocks.WATER.defaultBlockState().setValue(BlockStateProperties.LEVEL, 8);
    private static final BlockState BOOKSHELF = Blocks.BOOKSHELF.defaultBlockState();
    private static final BlockState MOSS_BLOCK = Blocks.MOSS_BLOCK.defaultBlockState();
    private static final BlockState MANGROVE_ROOTS = Blocks.MANGROVE_ROOTS.defaultBlockState();
    private static final BlockState MUDDY_ROOTS = Blocks.MUDDY_MANGROVE_ROOTS.defaultBlockState();
    private static final BlockState GRASS = Blocks.GRASS.defaultBlockState();
    private static final BlockState FERN = Blocks.FERN.defaultBlockState();
    private static final BlockState[] FLOWERS = {
            Blocks.DANDELION.defaultBlockState(), Blocks.POPPY.defaultBlockState(),
            Blocks.AZURE_BLUET.defaultBlockState(), Blocks.OXEYE_DAISY.defaultBlockState(),
            Blocks.CORNFLOWER.defaultBlockState(), Blocks.PINK_TULIP.defaultBlockState(),
            Blocks.ALLIUM.defaultBlockState(), Blocks.LILY_OF_THE_VALLEY.defaultBlockState()
    };
    private static final BlockState[] JUNGLE_FLOWERS = {
            Blocks.BLUE_ORCHID.defaultBlockState(), Blocks.ALLIUM.defaultBlockState(),
            Blocks.POPPY.defaultBlockState(), Blocks.LILY_OF_THE_VALLEY.defaultBlockState()
    };

    private IslaShape shape;
    private IslaStyle style;
    private int styleId;
    private int version;
    private int cx;
    private int cz;
    private int top;
    private int radius;
    private long seed;
    private double fallAngle;
    private int groundVine;
    private int groundFall;
    private boolean overWater;

    private int trunkBase;
    private int[] trunkAx;
    private int[] trunkAz;

    public IslaPiece(int cx, int cz, int top, int radius, long seed, double fallAngle,
                     int groundVine, int groundFall, boolean overWater, int styleId) {
        this(new IslaShape(seed, radius, fallAngle, styleId, false), cx, cz, top, radius, seed, fallAngle,
                groundVine, groundFall, overWater, styleId, CURRENT_VERSION);
    }

    private IslaPiece(IslaShape shape, int cx, int cz, int top, int radius, long seed, double fallAngle,
                      int groundVine, int groundFall, boolean overWater, int styleId, int version) {
        super(ModStructures.ISLA_PIECE.get(), 0, computeBox(shape, cx, cz, top, radius, groundVine, groundFall));
        this.shape = shape;
        this.styleId = styleId;
        this.style = IslaStyle.get(styleId);
        this.version = version;
        this.cx = cx;
        this.cz = cz;
        this.top = top;
        this.radius = radius;
        this.seed = seed;
        this.fallAngle = fallAngle;
        this.groundVine = groundVine;
        this.groundFall = groundFall;
        this.overWater = overWater;
        initTrunk();
    }

    public IslaPiece(CompoundTag tag) {
        super(ModStructures.ISLA_PIECE.get(), tag);
        this.cx = tag.getInt("Cx");
        this.cz = tag.getInt("Cz");
        this.top = tag.getInt("Top");
        this.radius = tag.getInt("Radius");
        this.seed = tag.getLong("Seed");
        this.fallAngle = tag.getDouble("FallAngle");
        this.groundVine = tag.getInt("GroundVine");
        this.groundFall = tag.getInt("GroundFall");
        this.overWater = tag.getBoolean("OverWater");
        this.version = tag.contains("Ver") ? tag.getInt("Ver") : 1;
        this.styleId = tag.getInt("Style");
        this.style = IslaStyle.get(styleId);
        this.shape = new IslaShape(seed, radius, fallAngle, styleId, version < CURRENT_VERSION);
        initTrunk();
    }

    private static BoundingBox computeBox(IslaShape shape, int cx, int cz, int top, int radius,
                                          int groundVine, int groundFall) {
        int m = shape.legacy ? radius + 12 : shape.maxR + 20;
        int extra = shape.legacy ? 16 : 28;
        return new BoundingBox(cx - m, Math.min(groundVine, groundFall) - 4, cz - m,
                cx + m, top + extra, cz + m);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Cx", cx);
        tag.putInt("Cz", cz);
        tag.putInt("Top", top);
        tag.putInt("Radius", radius);
        tag.putLong("Seed", seed);
        tag.putDouble("FallAngle", fallAngle);
        tag.putInt("GroundVine", groundVine);
        tag.putInt("GroundFall", groundFall);
        tag.putBoolean("OverWater", overWater);
        tag.putInt("Ver", version);
        tag.putInt("Style", styleId);
    }

    // ------------------------------------------------------------------ helpers

    private void initTrunk() {
        trunkBase = groundVine - 2;
        int len = top + 2 - trunkBase + 1;
        trunkAx = new int[len];
        trunkAz = new int[len];
        for (int i = 0; i < len; i++) {
            int y = trunkBase + i;
            double f = (double) (y - groundVine) / Math.max(1, top - groundVine);
            f = Math.max(0.0D, Math.min(1.0D, f));
            double amp = 2.0D * (1.0D - f);
            trunkAx[i] = shape.vineX + (int) Math.round(amp * Math.sin(y * 0.16D + shape.vinePhaseX));
            trunkAz[i] = shape.vineZ + (int) Math.round(amp * Math.cos(y * 0.13D + shape.vinePhaseZ));
        }
    }

    private boolean isTrunk(int rx, int y, int rz) {
        int i = y - trunkBase;
        if (i < 0 || i >= trunkAx.length || y > top + 1) {
            return false;
        }
        int ax = trunkAx[i];
        int az = trunkAz[i];
        return (rx == ax || rx == ax + shape.vineSx) && (rz == az || rz == az + shape.vineSz);
    }

    private static void put(WorldGenLevel level, BoundingBox box, int x, int y, int z, BlockState state) {
        if (box.isInside(x, y, z)) {
            level.setBlock(new BlockPos(x, y, z), state, 2);
        }
    }

    private static boolean isAirAt(WorldGenLevel level, BoundingBox box, int x, int y, int z) {
        return box.isInside(x, y, z) && level.getBlockState(new BlockPos(x, y, z)).isAir();
    }

    private static void putIfAir(WorldGenLevel level, BoundingBox box, int x, int y, int z, BlockState state) {
        if (isAirAt(level, box, x, y, z)) {
            level.setBlock(new BlockPos(x, y, z), state, 2);
        }
    }


    private BlockState brickMix(int a, int b, int c) {
        double r = shape.rnd(a, b, c);
        if (r < style.cut1) {
            return style.brick;
        }
        if (r < style.cut2) {
            return style.mossy;
        }
        return style.cracked;
    }

    // --------------------------------------------------------------- generacion

    @Override
    public void postProcess(WorldGenLevel level, StructureManager structureManager, ChunkGenerator generator,
                            RandomSource random, BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        int r = shape.legacy ? shape.radius : shape.maxR;
        int ix0 = Math.max(box.minX(), cx - r - 3);
        int ix1 = Math.min(box.maxX(), cx + r + 3);
        int iz0 = Math.max(box.minZ(), cz - r - 3);
        int iz1 = Math.min(box.maxZ(), cz + r + 3);

        if (ix0 <= ix1 && iz0 <= iz1) {
            placeBody(level, box, ix0, ix1, iz0, iz1);
            placeLakeAndChannel(level, box, ix0, ix1, iz0, iz1);
            placePlaza(level, box, ix0, ix1, iz0, iz1);
            placeFlora(level, box, ix0, ix1, iz0, iz1);
            placeUndersideVines(level, box, ix0, ix1, iz0, iz1);
        }
        placeCrater(level, box);
        switch (shape.shrineKind) {
            case IslaShape.KIND_SHRINE -> placeShrine(level, box, random);
            case IslaShape.KIND_TOWER -> placeTower(level, box, random);
            case IslaShape.KIND_NEST -> placeNest(level, box, random);
            default -> {
            }
        }
        placePillars(level, box);
        placeCenterpiece(level, box, random);
        placeTrees(level, box);
        placeVine(level, box);
        placeWaterfall(level, box);
        placeIslets(level, box, random);
        spawnDragons(level, box);
    }

    private void placeBody(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz)) {
                    continue;
                }
                int topY = top + shape.topOffset(rx, rz);
                int botY = top + shape.bottomOffset(rx, rz);
                boolean beach = shape.nearLake(rx, rz, 1.4D);
                for (int y = botY; y <= topY; y++) {
                    put(level, box, x, y, z, bodyBlock(rx, rz, y, topY, botY, beach));
                }
            }
        }
    }

    private BlockState bodyBlock(int rx, int rz, int y, int topY, int botY, boolean beach) {
        double r = shape.rnd(rx, y, rz);
        if (y == topY) {
            if (beach) {
                return style.beach;
            }
            return r < style.topPatch ? style.top2 : style.top;
        }
        int dy = topY - y;
        if (dy <= 3) {
            if (beach && dy <= 2) {
                return style.beach;
            }
            return r < 0.12D ? style.dirtB : style.dirtA;
        }
        if (y <= botY + 1) {
            if (r < 0.45D) {
                return style.deep[0];
            }
            if (r < 0.65D) {
                return style.deep[1];
            }
            if (r < 0.82D) {
                return style.deep[2];
            }
            if (r < 0.94D) {
                return style.deep[3];
            }
            return style.deep[4];
        }
        if (r < 0.10D) {
            return style.mid[1];
        }
        if (r < 0.16D) {
            return style.mid[2];
        }
        return style.mid[0];
    }

    private void placeLakeAndChannel(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz) || !shape.nearLake(rx, rz, 1.0D)) {
                    continue;
                }
                double r = shape.rnd(rx, 3, rz);
                put(level, box, x, top - 4, z, r < 0.5D ? style.lakeFloor[0] : (r < 0.8D ? style.lakeFloor[1] : style.lakeFloor[2]));
                for (int y = top - 3; y <= top - 1; y++) {
                    boolean ice = y == top - 1 && style.lakeCover != null && !shape.nearChannel(rx, rz);
                    put(level, box, x, y, z, ice ? style.lakeCover : WATER);
                }
                for (int y = top; y <= top + 4; y++) {
                    put(level, box, x, y, z, AIR);
                }
            }
        }
        for (int[] cell : shape.channel) {
            int x = cx + cell[0];
            int z = cz + cell[1];
            put(level, box, x, top - 1, z, WATER);
            for (int y = top; y <= top + 4; y++) {
                put(level, box, x, y, z, AIR);
            }
        }
        int lx = cx + shape.lipX;
        int lz = cz + shape.lipZ;
        if (box.isInside(lx, top - 1, lz)) {
            level.scheduleTick(new BlockPos(lx, top - 1, lz), Fluids.WATER, 0);
        }
    }

    private BlockState plazaBlock(int rx, int rz) {
        double d = Math.sqrt((double) rx * rx + (double) rz * rz);
        double r = shape.rnd(rx, 9, rz);
        if (d <= 1.6D) {
            return style.chiseled;
        }
        if (d >= 2.6D && d <= 3.4D) {
            return r < 0.8D ? style.accent : style.brick;
        }
        if (shape.plazaR >= 7.0D && d >= shape.plazaR - 1.3D && d <= shape.plazaR - 0.5D) {
            return r < 0.5D ? style.accent : style.polished;
        }
        if (r < 0.6D) {
            return style.brick;
        }
        if (r < 0.82D) {
            return style.mossy;
        }
        if (r < 0.92D) {
            return style.cracked;
        }
        return style.rubble;
    }

    private void placePlaza(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (shape.inPlaza(rx, rz)) {
                    put(level, box, x, top, z, plazaBlock(rx, rz));
                }
            }
        }
    }

    /** Vegetacion del suelo segun el tipo de isla; null si ese bloque se queda vacio. */
    private BlockState floraFor(BlockState below, int rx, int rz) {
        double r = shape.rnd(rx, 11, rz);
        switch (style.flora) {
            case SNOW:
                if (r < 0.22D) {
                    return GRASS;
                } else if (r < 0.32D) {
                    return FERN;
                } else if (r < 0.37D) {
                    return Blocks.SWEET_BERRY_BUSH.defaultBlockState().setValue(SweetBerryBushBlock.AGE, 3);
                } else if (r < 0.41D) {
                    return Blocks.SPRUCE_SAPLING.defaultBlockState();
                }
                return null;
            case VOLCANIC: {
                boolean warped = below.is(Blocks.WARPED_NYLIUM);
                if (r < 0.26D) {
                    return (warped ? Blocks.WARPED_ROOTS : Blocks.CRIMSON_ROOTS).defaultBlockState();
                } else if (r < 0.31D) {
                    return (warped ? Blocks.WARPED_FUNGUS : Blocks.CRIMSON_FUNGUS).defaultBlockState();
                }
                return null;
            }
            case CRYSTAL:
                if (r < 0.08D) {
                    return Blocks.AMETHYST_CLUSTER.defaultBlockState();
                } else if (r < 0.14D) {
                    return Blocks.LARGE_AMETHYST_BUD.defaultBlockState();
                } else if (r < 0.20D) {
                    return Blocks.MEDIUM_AMETHYST_BUD.defaultBlockState();
                } else if (r < 0.26D) {
                    return Blocks.SMALL_AMETHYST_BUD.defaultBlockState();
                } else if (r < 0.34D) {
                    return Blocks.MOSS_CARPET.defaultBlockState();
                } else if (r < 0.355D) {
                    return Blocks.FLOWERING_AZALEA.defaultBlockState();
                }
                return null;
            case JUNGLE:
                if (r < 0.28D) {
                    return GRASS;
                } else if (r < 0.37D) {
                    return FERN;
                } else if (r < 0.45D) {
                    return JUNGLE_FLOWERS[(int) (shape.rnd(rx, 12, rz) * JUNGLE_FLOWERS.length) % JUNGLE_FLOWERS.length];
                } else if (r < 0.47D) {
                    return Blocks.MELON.defaultBlockState();
                } else if (r < 0.50D) {
                    return style.capLeaves;
                }
                return null;
            case DESERT:
                if (r < 0.05D) {
                    return Blocks.DEAD_BUSH.defaultBlockState();
                } else if (r < 0.075D) {
                    return Blocks.CACTUS.defaultBlockState();
                }
                return null;
            default:
                if (r < 0.26D) {
                    return GRASS;
                } else if (r < 0.31D) {
                    return FERN;
                } else if (r < 0.40D) {
                    return FLOWERS[(int) (shape.rnd(rx, 12, rz) * FLOWERS.length) % FLOWERS.length];
                } else if (r < 0.45D) {
                    return Blocks.PINK_PETALS.defaultBlockState()
                            .setValue(BlockStateProperties.FLOWER_AMOUNT, 1 + (int) (shape.rnd(rx, 13, rz) * 4.0D));
                } else if (r < 0.455D) {
                    return Blocks.FLOWERING_AZALEA.defaultBlockState();
                }
                return null;
        }
    }

    private void placeFlora(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz) || rx * rx + rz * rz <= 36 || shape.nearLake(rx, rz, 1.45D)
                        || shape.nearChannel(rx, rz) || shape.inShrine(rx, rz, 1) || shape.nearCrater(rx, rz, 2.0D)) {
                    continue;
                }
                int ty = top + shape.topOffset(rx, rz);
                if (!box.isInside(x, ty, z) || !box.isInside(x, ty + 1, z)) {
                    continue;
                }
                BlockState below = level.getBlockState(new BlockPos(x, ty, z));
                if (!(below.is(style.top.getBlock()) || below.is(style.top2.getBlock()))
                        || !level.getBlockState(new BlockPos(x, ty + 1, z)).isAir()) {
                    continue;
                }
                BlockState state = floraFor(below, rx, rz);
                if (state == null) {
                    continue;
                }
                put(level, box, x, ty + 1, z, state);
                if (state.is(Blocks.CACTUS)) {
                    int extra = (int) (shape.rnd(rx, 14, rz) * 3.0D);
                    for (int k = 1; k <= extra; k++) {
                        put(level, box, x, ty + 1 + k, z, state);
                    }
                }
            }
        }
    }

    private void hangVines(WorldGenLevel level, BoundingBox box, int x, int startY, int z, int length, double berries) {
        for (int k = 0; k < length; k++) {
            int y = startY - k;
            if (!isAirAt(level, box, x, y, z)) {
                break;
            }
            boolean hasBerries = shape.rnd(x, y, z + 77) < berries;
            BlockState state = (k == length - 1 ? Blocks.CAVE_VINES : Blocks.CAVE_VINES_PLANT).defaultBlockState()
                    .setValue(BlockStateProperties.BERRIES, hasBerries);
            put(level, box, x, y, z, state);
        }
    }

    private void hangColumn(WorldGenLevel level, BoundingBox box, int x, int startY, int z, int length) {
        int last = Integer.MIN_VALUE;
        for (int k = 0; k < Math.min(length, 4); k++) {
            int y = startY - k;
            if (!isAirAt(level, box, x, y, z)) {
                break;
            }
            put(level, box, x, y, z, style.column);
            last = y;
        }
        if (last != Integer.MIN_VALUE && style.columnTip != null) {
            put(level, box, x, last, z, style.columnTip);
        }
    }

    private void placeUndersideVines(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz)) {
                    continue;
                }
                double f = shape.frac(rx, rz);
                if (f < 0.3D || f > 0.96D || shape.rnd(rx, 91, rz) >= 0.07D) {
                    continue;
                }
                int botY = top + shape.bottomOffset(rx, rz);
                int length = 2 + (int) (shape.rnd(rx, 92, rz) * 6.0D);
                if (style.hang == IslaStyle.Hang.VINES) {
                    hangVines(level, box, x, botY - 1, z, length, 0.35D);
                } else {
                    hangColumn(level, box, x, botY - 1, z, length);
                }
            }
        }
    }

    // ------------------------------------------------- crater, santuario, torre, nido

    private void placeCrater(WorldGenLevel level, BoundingBox box) {
        if (!shape.hasCrater) {
            return;
        }
        int px = cx + shape.craterX;
        int pz = cz + shape.craterZ;
        int reach = (int) Math.ceil(IslaShape.CRATER_R + 1.6D);
        for (int dx = -reach; dx <= reach; dx++) {
            for (int dz = -reach; dz <= reach; dz++) {
                double d = Math.sqrt((double) dx * dx + (double) dz * dz);
                if (d <= IslaShape.CRATER_R) {
                    put(level, box, px + dx, top - 1, pz + dz, LAVA);
                    put(level, box, px + dx, top, pz + dz, AIR);
                } else if (d <= IslaShape.CRATER_R + 1.4D) {
                    put(level, box, px + dx, top, pz + dz, Blocks.BASALT.defaultBlockState());
                    if (shape.rnd(dx, 80, dz) < 0.85D) {
                        put(level, box, px + dx, top + 1, pz + dz, Blocks.BASALT.defaultBlockState());
                    }
                }
            }
        }
    }

    private Direction doorDirection() {
        if (shape.doorX > 0) {
            return Direction.EAST;
        } else if (shape.doorX < 0) {
            return Direction.WEST;
        } else if (shape.doorZ > 0) {
            return Direction.SOUTH;
        }
        return Direction.NORTH;
    }

    private void placeShrine(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int sx = cx + shape.shrineX;
        int sz = cz + shape.shrineZ;
        int half = IslaShape.SHRINE_HALF;
        Direction doorDir = doorDirection();
        BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, doorDir);

        for (int x = sx - half; x <= sx + half; x++) {
            for (int z = sz - half; z <= sz + half; z++) {
                if (x < box.minX() || x > box.maxX() || z < box.minZ() || z > box.maxZ()) {
                    continue;
                }
                int ox = x - sx;
                int oz = z - sz;
                boolean edge = Math.abs(ox) == half || Math.abs(oz) == half;
                int along = ox * shape.doorX + oz * shape.doorZ;
                int perp = shape.doorX != 0 ? oz : ox;

                double fr = shape.rnd(ox, 20, oz);
                put(level, box, x, top, z, fr < 0.55D ? style.brick : (fr < 0.8D ? style.mossy
                        : (fr < 0.92D ? style.cracked : style.polished)));

                if (edge) {
                    boolean corner = Math.abs(ox) == half && Math.abs(oz) == half;
                    boolean middle = ox == 0 || oz == 0;
                    for (int k = 1; k <= 4; k++) {
                        boolean door = along == half && perp == 0 && k <= 2;
                        boolean window = middle && along != half && k >= 2 && k <= 3;
                        if (door || window) {
                            put(level, box, x, top + k, z, AIR);
                            continue;
                        }
                        double r = shape.rnd(ox, 21 + k, oz);
                        if (!corner && k >= 3 && r < 0.18D) {
                            continue;
                        }
                        if (k == 4 && r < 0.45D) {
                            continue;
                        }
                        put(level, box, x, top + k, z, corner && k == 1 ? style.chiseled : brickMix(ox, 30 + k, oz));
                    }
                    double roofR = shape.rnd(ox, 40, oz);
                    if (roofR >= 0.1D) {
                        put(level, box, x, top + 5, z, style.brick);
                    }
                } else {
                    for (int k = 1; k <= 4; k++) {
                        put(level, box, x, top + k, z, AIR);
                    }
                    if (shape.rnd(ox, 41, oz) < 0.65D) {
                        put(level, box, x, top + 5, z, style.slab);
                    }
                    boolean back = along == -2;
                    if (back && perp == 0) {
                        put(level, box, x, top + 1, z, BOOKSHELF);
                        put(level, box, x, top + 2, z, BOOKSHELF);
                    } else if (back && Math.abs(perp) == 2) {
                        BlockPos chestPos = new BlockPos(x, top + 1, z);
                        createChest(level, box, random, chestPos, CHEST_LOOT, chest);
                    } else if (along == 2 && Math.abs(perp) == 2) {
                        put(level, box, x, top + 1, z, style.lantern);
                    } else if (perp == 0) {
                        put(level, box, x, top + 1, z, style.carpet);
                    } else if (shape.rnd(ox, 42, oz) < 0.15D) {
                        put(level, box, x, top + 1, z, Blocks.MOSS_CARPET.defaultBlockState());
                    }
                }
            }
        }
    }

    /** Torre en ruinas: dos pisos unidos por una escalera, un cofre abajo y otro arriba. */
    private void placeTower(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int sx = cx + shape.shrineX;
        int sz = cz + shape.shrineZ;
        int half = 2;
        int towerH = shape.towerH;
        Direction doorDir = doorDirection();
        BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, doorDir);
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, doorDir);

        for (int x = sx - IslaShape.SHRINE_HALF; x <= sx + IslaShape.SHRINE_HALF; x++) {
            for (int z = sz - IslaShape.SHRINE_HALF; z <= sz + IslaShape.SHRINE_HALF; z++) {
                if (x < box.minX() || x > box.maxX() || z < box.minZ() || z > box.maxZ()) {
                    continue;
                }
                int ox = x - sx;
                int oz = z - sz;
                int ax = Math.abs(ox);
                int az = Math.abs(oz);
                if (ax > half || az > half) {
                    // escombros alrededor de la torre
                    double rr = shape.rnd(ox, 60, oz);
                    if (rr < 0.22D) {
                        put(level, box, x, top + 1, z, rr < 0.11D ? style.mossy : style.cracked);
                    }
                    continue;
                }
                int along = ox * shape.doorX + oz * shape.doorZ;
                int perp = shape.doorX != 0 ? oz : ox;
                put(level, box, x, top, z, brickMix(ox, 59, oz));

                boolean wall = ax == half || az == half;
                if (wall) {
                    boolean corner = ax == half && az == half;
                    boolean middle = ox == 0 || oz == 0;
                    int wallH = corner ? towerH : towerH - (int) (shape.rnd(ox, 61, oz) * 4.0D);
                    for (int k = 1; k <= wallH; k++) {
                        boolean door = along == half && perp == 0 && k <= 2;
                        boolean window = middle && along != half && (k == 3 || k == 4 || k == 7 || k == 8);
                        if (door || window) {
                            put(level, box, x, top + k, z, AIR);
                            continue;
                        }
                        put(level, box, x, top + k, z, corner && k == 1 ? style.chiseled : brickMix(ox, 62 + k, oz));
                    }
                } else {
                    for (int k = 1; k <= towerH; k++) {
                        put(level, box, x, top + k, z, AIR);
                    }
                    boolean ladderCell = along == -1 && perp == 0;
                    if (ladderCell) {
                        for (int k = 1; k <= 6; k++) {
                            put(level, box, x, top + k, z, ladder);
                        }
                    } else {
                        put(level, box, x, top + 5, z, style.brick);
                    }
                    if (along == -1 && perp == 1) {
                        createChest(level, box, random, new BlockPos(x, top + 1, z), CHEST_LOOT, chest);
                    } else if (along == -1 && perp == -1) {
                        createChest(level, box, random, new BlockPos(x, top + 6, z), CHEST_LOOT, chest);
                    } else if (along == 1 && Math.abs(perp) == 1) {
                        put(level, box, x, top + 1, z, style.lantern);
                    } else if (along == 1 && perp == 0) {
                        put(level, box, x, top + 1, z, style.carpet);
                    }
                }
            }
        }
    }

    /** Nido de dragoncitos: aro de musgo, paja en el centro y un cofre con tesoro. */
    private void placeNest(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int sx = cx + shape.shrineX;
        int sz = cz + shape.shrineZ;
        BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, doorDirection());
        for (int ox = -IslaShape.SHRINE_HALF; ox <= IslaShape.SHRINE_HALF; ox++) {
            for (int oz = -IslaShape.SHRINE_HALF; oz <= IslaShape.SHRINE_HALF; oz++) {
                double d = Math.sqrt((double) ox * ox + (double) oz * oz);
                if (d > 3.4D) {
                    continue;
                }
                int x = sx + ox;
                int z = sz + oz;
                if (d <= 2.4D) {
                    put(level, box, x, top, z, Blocks.HAY_BLOCK.defaultBlockState());
                    for (int k = 1; k <= 3; k++) {
                        put(level, box, x, top + k, z, AIR);
                    }
                } else {
                    put(level, box, x, top, z, MOSS_BLOCK);
                    if (shape.rnd(ox, 70, oz) < 0.85D) {
                        put(level, box, x, top + 1, z, MOSS_BLOCK);
                    }
                    if (shape.rnd(ox, 71, oz) < 0.25D) {
                        put(level, box, x, top + 2, z, style.lantern);
                    }
                }
            }
        }
        createChest(level, box, random, new BlockPos(sx, top + 1, sz), CHEST_LOOT, chest);
    }

    private void placePillars(WorldGenLevel level, BoundingBox box) {
        int n = shape.pillarCount;
        for (int i = 0; i < n; i++) {
            int h = shape.pillarHeight[i];
            if (h <= 0) {
                continue;
            }
            int px = cx + shape.pillars[i][0];
            int pz = cz + shape.pillars[i][1];
            for (int k = 1; k <= h; k++) {
                BlockState state;
                if (k == 1 || (k == h && shape.rnd(i, 50, k) < 0.5D)) {
                    state = style.chiseled;
                } else {
                    state = brickMix(i, 51, k);
                }
                put(level, box, px, top + k, pz, state);
            }
        }

        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            int hi = shape.pillarHeight[i];
            int hj = shape.pillarHeight[j];
            if (!shape.arch[i] || hi < 5 || hj < 5) {
                continue;
            }
            int ax = shape.pillars[i][0];
            int az = shape.pillars[i][1];
            int bx = shape.pillars[j][0];
            int bz = shape.pillars[j][1];
            int steps = Math.max(Math.abs(bx - ax), Math.abs(bz - az));
            int y = top + Math.min(hi, hj) + 1;
            for (int s = 1; s < steps; s++) {
                double t = (double) s / steps;
                int lx = (int) Math.round(ax + (bx - ax) * t);
                int lz = (int) Math.round(az + (bz - az) * t);
                if (shape.rnd(lx, 52, lz) < 0.12D) {
                    continue;
                }
                put(level, box, cx + lx, y, cz + lz, brickMix(lx, 53, lz));
                if (style.hang == IslaStyle.Hang.VINES && shape.rnd(lx, 54, lz) < 0.45D) {
                    hangVines(level, box, cx + lx, y - 1, cz + lz, 1 + (int) (shape.rnd(lx, 55, lz) * 3.0D), 0.4D);
                }
            }
        }
    }

    private void placeCenterpiece(WorldGenLevel level, BoundingBox box, RandomSource random) {
        // peana y escalones
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                put(level, box, cx + dx, top + 1, cz + dz, dx == 0 && dz == 0 ? style.chiseled : style.slab);
            }
        }
        // estatua
        Direction facing = Direction.from2DDataValue((int) (shape.rnd(1, 2, 3) * 4.0D) & 3);
        BlockState statue = ModBlocks.DRAGON_STATUE.get().defaultBlockState().setValue(IslandStatueBlock.FACING, facing);
        if (box.isInside(cx, top + 2, cz)) {
            BlockPos statuePos = new BlockPos(cx, top + 2, cz);
            level.setBlock(statuePos, statue, 2);
            BlockEntity blockEntity = level.getBlockEntity(statuePos);
            if (blockEntity instanceof IslandStatueBlockEntity data) {
                data.radius = shape.legacy ? shape.radius : shape.maxR;
                data.topY = top;
                data.bottomY = top - 2 - shape.depth - 4;
                data.corridorMinY = Math.min(groundVine, groundFall) - 3;
                data.vineX = cx + shape.vineX;
                data.vineZ = cz + shape.vineZ;
                data.vineSx = shape.vineSx;
                data.vineSz = shape.vineSz;
                data.fallX = cx + shape.fallX;
                data.fallZ = cz + shape.fallZ;
                data.setChanged();
            }
        }
        // cofres junto a los pilares
        int n = shape.pillarCount;
        int[] chestPillars = {1, n / 2 + 1};
        for (int idx : chestPillars) {
            double a = idx * Math.PI * 2.0D / n + Math.PI / n;
            int rx = (int) Math.round(Math.cos(a) * (shape.pillarR - 1.2D));
            int rz = (int) Math.round(Math.sin(a) * (shape.pillarR - 1.2D));
            if (shape.inShrine(rx, rz, 1) || shape.nearLake(rx, rz, 1.5D) || shape.nearChannel(rx, rz)) {
                continue;
            }
            Direction dir = Math.abs(rx) > Math.abs(rz)
                    ? (rx > 0 ? Direction.WEST : Direction.EAST)
                    : (rz > 0 ? Direction.NORTH : Direction.SOUTH);
            BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, dir);
            createChest(level, box, random, new BlockPos(cx + rx, top + 1, cz + rz), CHEST_LOOT, chest);
        }
        // las islas pequenas no tienen santuario: su cofre esta junto a la estatua
        if (shape.shrineKind == IslaShape.KIND_NONE) {
            BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.WEST);
            createChest(level, box, random, new BlockPos(cx + 2, top + 1, cz), CHEST_LOOT, chest);
        }
    }

    // ------------------------------------------------------------------ arboles

    private void placeTrees(WorldGenLevel level, BoundingBox box) {
        int gi0 = Math.floorDiv(box.minX() - cx - 4, 6);
        int gi1 = Math.floorDiv(box.maxX() - cx + 4, 6);
        int gj0 = Math.floorDiv(box.minZ() - cz - 4, 6);
        int gj1 = Math.floorDiv(box.maxZ() - cz + 4, 6);
        for (int gi = gi0; gi <= gi1; gi++) {
            for (int gj = gj0; gj <= gj1; gj++) {
                if (shape.rnd(gi, 5, gj) > style.treeChance) {
                    continue;
                }
                int tx = gi * 6 + (int) (shape.rnd(gi, 6, gj) * 6.0D);
                int tz = gj * 6 + (int) (shape.rnd(gi, 7, gj) * 6.0D);
                if (!shape.inside(tx, tz) || shape.frac(tx, tz) > 0.78D || tx * tx + tz * tz < shape.treeClearSq
                        || shape.nearLake(tx, tz, 1.7D) || shape.nearChannel(tx, tz) || shape.inShrine(tx, tz, 4)
                        || shape.nearCrater(tx, tz, 3.5D)) {
                    continue;
                }
                int ty = top + shape.topOffset(tx, tz) + 1;
                placeTree(level, box, cx + tx, ty, cz + tz, shape.rnd(gi, 8, gj), gi, gj);
            }
        }
    }

    private void placeTree(WorldGenLevel level, BoundingBox box, int x, int y, int z, double kind, int gi, int gj) {
        IslaStyle.TreeSet set = style.treeSets[style.treeSets.length - 1];
        for (IslaStyle.TreeSet candidate : style.treeSets) {
            if (kind < candidate.cut) {
                set = candidate;
                break;
            }
        }
        int height = set.minH + (int) (shape.rnd(gi, 9, gj) * set.varH);
        switch (style.tree) {
            case CONE -> placeCone(level, box, x, y, z, set, height);
            case FUNGUS -> placeFungus(level, box, x, y, z, set, height, gi, gj);
            case SPIRE -> placeSpire(level, box, x, y, z, set, height);
            case PALM -> placePalm(level, box, x, y, z, set, height);
            case TALL -> placeBlob(level, box, x, y, z, set, height, 4, 12.5D);
            default -> placeBlob(level, box, x, y, z, set, height, 3, 7.5D);
        }
    }

    /** Arbol redondeado: tronco y copa esferica. */
    private void placeBlob(WorldGenLevel level, BoundingBox box, int x, int y, int z, IslaStyle.TreeSet set,
                           int height, int reach, double maxDist) {
        for (int k = 0; k < height; k++) {
            put(level, box, x, y + k, z, set.log);
        }
        int ly = y + height;
        for (int dx = -reach; dx <= reach; dx++) {
            for (int dy = -2; dy <= 1; dy++) {
                for (int dz = -reach; dz <= reach; dz++) {
                    double dist = dx * dx + dy * dy * 1.6D + dz * dz;
                    if (dist > maxDist || (dx == 0 && dz == 0 && dy <= 0)) {
                        continue;
                    }
                    if (shape.rnd(x + dx, ly + dy, z + dz) < 0.1D) {
                        continue;
                    }
                    BlockState leaf = shape.rnd(x + dx, ly + dy + 100, z + dz) < 0.3D ? set.leafB : set.leafA;
                    putIfAir(level, box, x + dx, ly + dy, z + dz, leaf);
                }
            }
        }
    }

    /** Abeto: tronco y capas de hojas que se ensanchan hacia abajo. */
    private void placeCone(WorldGenLevel level, BoundingBox box, int x, int y, int z, IslaStyle.TreeSet set, int height) {
        for (int k = 0; k < height; k++) {
            put(level, box, x, y + k, z, set.log);
        }
        for (int i = 0; i < height; i++) {
            int ly = y + height + 1 - i;
            int rad = Math.min(3, (i + 1) / 2);
            int lim = rad + (rad >= 2 ? 1 : 0);
            for (int dx = -rad; dx <= rad; dx++) {
                for (int dz = -rad; dz <= rad; dz++) {
                    if (Math.abs(dx) + Math.abs(dz) > lim) {
                        continue;
                    }
                    putIfAir(level, box, x + dx, ly, z + dz, set.leafA);
                }
            }
        }
    }

    /** Hongo gigante del Nether: tallo grueso, sombrero plano y luces de hongo debajo. */
    private void placeFungus(WorldGenLevel level, BoundingBox box, int x, int y, int z, IslaStyle.TreeSet set,
                             int height, int gi, int gj) {
        for (int k = 0; k < height; k++) {
            put(level, box, x, y + k, z, set.log);
        }
        int ly = y + height;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                double dist = dx * dx + dz * dz;
                if (dist <= 9.5D) {
                    putIfAir(level, box, x + dx, ly, z + dz, set.leafA);
                    if (dist >= 5.0D && shape.rnd(x + dx, ly - 1, z + dz) < 0.4D) {
                        putIfAir(level, box, x + dx, ly - 1, z + dz, set.leafA);
                    } else if (dist <= 4.5D && shape.rnd(x + dx, ly - 2, z + dz) < 0.25D) {
                        putIfAir(level, box, x + dx, ly - 1, z + dz, set.leafB);
                    }
                }
                if (dist <= 4.5D) {
                    putIfAir(level, box, x + dx, ly + 1, z + dz,
                            shape.rnd(x + dx, ly + 1, z + dz) < 0.15D ? set.leafB : set.leafA);
                }
            }
        }
    }

    /** Espina de amatista con otras mas pequenas a su alrededor. */
    private void placeSpire(WorldGenLevel level, BoundingBox box, int x, int y, int z, IslaStyle.TreeSet set, int height) {
        spireColumn(level, box, x, y, z, set, height);
        int[][] around = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int i = 0; i < around.length; i++) {
            double r = shape.rnd(x + around[i][0], 73 + i, z + around[i][1]);
            if (r < 0.65D) {
                int h = Math.max(1, (int) (height * (0.3D + r * 0.5D)));
                spireColumn(level, box, x + around[i][0], y, z + around[i][1], set, h);
            }
        }
    }

    private void spireColumn(WorldGenLevel level, BoundingBox box, int x, int y, int z, IslaStyle.TreeSet set, int h) {
        for (int k = 0; k < h; k++) {
            put(level, box, x, y + k, z, set.log);
        }
        put(level, box, x, y + h, z, set.leafA);
    }

    /** Palmera: tronco fino y hojas largas que caen en ocho direcciones. */
    private void placePalm(WorldGenLevel level, BoundingBox box, int x, int y, int z, IslaStyle.TreeSet set, int height) {
        for (int k = 0; k < height; k++) {
            put(level, box, x, y + k, z, set.log);
        }
        int ly = y + height;
        putIfAir(level, box, x, ly, z, set.leafA);
        putIfAir(level, box, x, ly + 1, z, set.leafA);
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        for (int[] dir : dirs) {
            boolean diagonal = dir[0] != 0 && dir[1] != 0;
            for (int k = 1; k <= (diagonal ? 2 : 3); k++) {
                int dy = k == 1 ? 1 : (k == 2 ? 0 : -1);
                putIfAir(level, box, x + dir[0] * k, ly + dy, z + dir[1] * k, set.leafA);
            }
        }
    }

    // ------------------------------------------- enredadera gigante y cascada

    private BlockState trunkBlock(int rx, int y, int rz) {
        double r = shape.rnd(rx, y, rz + 5);
        if (r < 0.55D) {
            return MOSS_BLOCK;
        }
        return r < 0.85D ? MANGROVE_ROOTS : MUDDY_ROOTS;
    }

    private void placeVine(WorldGenLevel level, BoundingBox box) {
        int vx = cx + shape.vineX;
        int vz = cz + shape.vineZ;
        int x0 = Math.max(box.minX(), vx - 6);
        int x1 = Math.min(box.maxX(), vx + 6);
        int z0 = Math.max(box.minZ(), vz - 6);
        int z1 = Math.min(box.maxZ(), vz + 6);
        if (x0 > x1 || z0 > z1) {
            return;
        }
        int yMax = top + 1;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                for (int y = trunkBase; y <= yMax; y++) {
                    if (isTrunk(rx, y, rz)) {
                        put(level, box, x, y, z, trunkBlock(rx, y, rz));
                        continue;
                    }
                    if (y < groundVine) {
                        continue;
                    }
                    boolean north = isTrunk(rx, y, rz - 1);
                    boolean south = isTrunk(rx, y, rz + 1);
                    boolean west = isTrunk(rx - 1, y, rz);
                    boolean east = isTrunk(rx + 1, y, rz);
                    if (!(north || south || west || east) || !isAirAt(level, box, x, y, z)) {
                        continue;
                    }
                    BlockState vine = Blocks.VINE.defaultBlockState()
                            .setValue(VineBlock.NORTH, north)
                            .setValue(VineBlock.SOUTH, south)
                            .setValue(VineBlock.WEST, west)
                            .setValue(VineBlock.EAST, east);
                    put(level, box, x, y, z, vine);
                }
            }
        }

        // copa sobre el extremo superior, fuera del camino hacia la isla
        int topIdx = top + 1 - trunkBase;
        double centerX = trunkAx[topIdx] + shape.vineSx * 0.5D;
        double centerZ = trunkAz[topIdx] + shape.vineSz * 0.5D;
        for (int dx = -3; dx <= 4; dx++) {
            for (int dz = -3; dz <= 4; dz++) {
                int rx = trunkAx[topIdx] + dx;
                int rz = trunkAz[topIdx] + dz;
                double dist = Math.sqrt((rx - centerX) * (rx - centerX) + (rz - centerZ) * (rz - centerZ));
                if (dist > 2.7D || shape.inside(rx, rz) || isTrunk(rx, top + 1, rz)) {
                    continue;
                }
                for (int k = 2; k <= 3; k++) {
                    if (shape.rnd(rx, top + k, rz) < 0.55D) {
                        putIfAir(level, box, cx + rx, top + k, cz + rz, style.capLeaves);
                    }
                }
            }
        }
    }

    private void placeWaterfall(WorldGenLevel level, BoundingBox box) {
        int fx = cx + shape.fallX;
        int fz = cz + shape.fallZ;
        if (box.isInside(fx, top - 1, fz)) {
            put(level, box, fx, top - 1, fz, FLOW_TOP);
            level.scheduleTick(new BlockPos(fx, top - 1, fz), Fluids.WATER, 0);
            for (int y = top - 2; y >= groundFall; y--) {
                put(level, box, fx, y, fz, FALLING_WATER);
            }
            level.scheduleTick(new BlockPos(fx, top - 2, fz), Fluids.WATER, 0);
        }
        if (!overWater) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    int px = fx + dx;
                    int pz = fz + dz;
                    int py = groundFall - 1;
                    if (box.isInside(px, py, pz) && !level.getBlockState(new BlockPos(px, py, pz)).isAir()) {
                        put(level, box, px, py, pz, WATER);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ islotes

    private void placeIslets(WorldGenLevel level, BoundingBox box, RandomSource random) {
        for (int[] islet : shape.islets) {
            int ix = cx + islet[0];
            int iz = cz + islet[1];
            int ir = islet[3];
            int topY = top + islet[2];
            int thick = islet[4];
            int decor = islet[5];

            int x0 = Math.max(box.minX(), ix - ir - 1);
            int x1 = Math.min(box.maxX(), ix + ir + 1);
            int z0 = Math.max(box.minZ(), iz - ir - 1);
            int z1 = Math.min(box.maxZ(), iz + ir + 1);
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    double d = Math.sqrt((double) (x - ix) * (x - ix) + (double) (z - iz) * (z - iz));
                    double edge = ir + 0.7D * (shape.rnd(x - cx, 74, z - cz) - 0.5D);
                    if (d > edge) {
                        continue;
                    }
                    double t = Math.max(0.0D, 1.0D - (d / ir) * (d / ir));
                    int botY = topY - 1 - (int) Math.round(thick * t);
                    for (int y = botY; y <= topY; y++) {
                        put(level, box, x, y, z, bodyBlock(x - cx, z - cz, y, topY, botY, false));
                    }
                }
            }

            if (!box.isInside(ix, topY + 1, iz)) {
                continue;
            }
            if (decor == 0) {
                placeTree(level, box, ix, topY + 1, iz, shape.rnd(islet[0], 72, islet[1]), islet[0], islet[1]);
            } else if (decor == 1) {
                put(level, box, ix, topY + 1, iz, style.chiseled);
                put(level, box, ix, topY + 2, iz, style.lantern);
            } else {
                BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.SOUTH);
                createChest(level, box, random, new BlockPos(ix, topY + 1, iz), CHEST_LOOT, chest);
            }
        }
    }

    // ---------------------------------------------------------------- dragoncitos

    private void spawnDragons(WorldGenLevel level, BoundingBox box) {
        for (int[] spawn : shape.spawns) {
            int x = cx + spawn[0];
            int z = cz + spawn[1];
            int y = top + shape.topOffset(spawn[0], spawn[1]) + 1;
            if (!box.isInside(x, y, z)) {
                continue;
            }
            DragoncitoEntity dragon = ModEntities.DRAGONCITO.get().create(level.getLevel());
            if (dragon == null) {
                continue;
            }
            BlockPos pos = new BlockPos(x, y, z);
            dragon.moveTo(x + 0.5D, y, z + 0.5D, (float) (shape.rnd(spawn[0], 60, spawn[1]) * 360.0D), 0.0F);
            dragon.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
            if (!shape.legacy && shape.rnd(spawn[0], 61, spawn[1]) < 0.65D) {
                dragon.setVariant(style.dragonVariant);
            }
            dragon.setHome(new BlockPos(cx, top + 1, cz), shape.maxR + 4);
            dragon.setPersistenceRequired();
            level.addFreshEntityWithPassengers(dragon);
        }
    }
}
