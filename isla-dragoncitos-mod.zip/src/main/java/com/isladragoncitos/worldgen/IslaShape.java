package com.isladragoncitos.worldgen;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Geometria de una isla, siempre en coordenadas RELATIVAS al centro (x, z).
 * Es una funcion pura de (semilla, radio, angulo de la cascada, estilo): cada chunk puede
 * generar su parte de la isla de forma independiente y el resultado encaja.
 * Con legacy=true reproduce exactamente las islas de la version 1.0 del mod.
 */
public final class IslaShape {
    public static final int SHRINE_HALF = 3;
    public static final double CRATER_R = 1.7D;

    public static final int KIND_NONE = 0;
    public static final int KIND_SHRINE = 1;
    public static final int KIND_TOWER = 2;
    public static final int KIND_NEST = 3;

    private static final int[] PILLAR_CHOICES = {6, 8, 8, 10, 12};

    public final long seed;
    public final int radius;
    public final int depth;
    /** Extension horizontal maxima de la isla (incluye irregularidades y alargamiento). */
    public final int maxR;
    public final double fallAngle;
    public final int styleId;
    public final boolean legacy;

    public final double plazaR;
    public final double pillarR;
    public final int pillarCount;
    public final double relief;
    public final int flatR2;
    public final int treeClearSq;
    public final int shrineKind;
    public final int towerH;

    private final double p1;
    private final double p2;
    private final double p3;
    private final int f1;
    private final int f2;
    private final int f3;
    private final double a1;
    private final double a2;
    private final double a3;
    private final double elong;
    private final double elongPhase;

    // lago principal y estanques
    private final double lakeX;
    private final double lakeZ;
    private final double lakeA;
    private final double lakeB;
    private final double axisCos;
    private final double axisSin;
    private final List<double[]> ponds = new ArrayList<>();

    // canal del lago al borde + cascada
    public final List<int[]> channel = new ArrayList<>();
    private final Set<Long> channelSet = new HashSet<>();
    public int lipX;
    public int lipZ;
    public int fallX;
    public int fallZ;

    // enredadera
    public final double vineAngle;
    public int vineX;
    public int vineZ;
    public int vineSx;
    public int vineSz;
    public final double vinePhaseX;
    public final double vinePhaseZ;

    // santuario / torre / nido
    public final double shrineAngle;
    public int shrineX;
    public int shrineZ;
    public int doorX;
    public int doorZ;

    // crater de lava (islas volcanicas)
    public boolean hasCrater;
    public int craterX;
    public int craterZ;

    // pilares
    public final int[][] pillars;
    public final int[] pillarHeight;
    public final boolean[] arch;

    // puntos de aparicion de dragoncitos
    public final List<int[]> spawns = new ArrayList<>();

    // islotes flotantes: {x, z, dy, radio, grosor, decoracion}
    public final List<int[]> islets = new ArrayList<>();

    public IslaShape(long seed, int radius, double fallAngle, int styleId, boolean legacy) {
        this.seed = seed;
        this.radius = radius;
        this.fallAngle = fallAngle;
        this.styleId = styleId;
        this.legacy = legacy;

        Random r = new Random(seed);
        this.p1 = r.nextDouble() * Math.PI * 2.0D;
        this.p2 = r.nextDouble() * Math.PI * 2.0D;
        this.p3 = r.nextDouble() * Math.PI * 2.0D;
        this.vineAngle = fallAngle + Math.PI + (r.nextDouble() - 0.5D) * 0.9D;
        this.shrineAngle = fallAngle + (r.nextBoolean() ? 1.0D : -1.0D) * (Math.PI / 2.0D)
                + (r.nextDouble() - 0.5D) * 0.5D;
        this.vinePhaseX = r.nextDouble() * Math.PI * 2.0D;
        this.vinePhaseZ = r.nextDouble() * Math.PI * 2.0D;

        // parametros nuevos: generador aparte, para no alterar el de las islas antiguas
        Random q = new Random(seed * 0x2545F4914F6CDD1DL + 0x9E3779B97F4A7C15L);

        if (legacy) {
            this.f1 = 3;
            this.f2 = 5;
            this.f3 = 7;
            this.a1 = 0.06D;
            this.a2 = 0.04D;
            this.a3 = 0.025D;
            this.elong = 0.0D;
            this.elongPhase = 0.0D;
            this.depth = radius - 6;
            this.relief = 1.8D;
            this.flatR2 = 100;
            this.plazaR = 5.0D;
            this.pillarR = 7.0D;
            this.pillarCount = 8;
            this.treeClearSq = 144;
            this.shrineKind = KIND_SHRINE;
            this.towerH = 8;
        } else {
            double rough = 0.6D + q.nextDouble() * 0.9D;
            this.f1 = 2 + q.nextInt(3);
            this.f2 = 5 + q.nextInt(2);
            this.f3 = 7 + q.nextInt(3);
            this.a1 = 0.06D * rough;
            this.a2 = 0.04D * rough;
            this.a3 = 0.025D * rough;
            this.elong = q.nextDouble() * 0.14D;
            this.elongPhase = q.nextDouble() * Math.PI * 2.0D;
            double thick = 0.7D + q.nextDouble() * 0.6D;
            this.depth = clampI((int) Math.round((6.0D + radius * 0.5D) * thick), 7, 32);
            this.relief = 1.2D + q.nextDouble() * 2.0D;
            double fr = Math.min(10.0D, radius * 0.42D);
            this.flatR2 = (int) (fr * fr);
            this.plazaR = clamp((double) Math.round(radius * 0.21D), 3.0D, 9.0D);
            this.pillarR = this.plazaR + 2.0D;
            this.pillarCount = radius < 16 ? 5 : (radius < 22 ? 6 : PILLAR_CHOICES[q.nextInt(PILLAR_CHOICES.length)]);
            double tc = Math.max(this.pillarR + 2.5D, Math.min(12.0D, radius * 0.5D));
            this.treeClearSq = (int) (tc * tc);
            double k = q.nextDouble();
            this.shrineKind = radius < 20 ? KIND_NONE : (k < 0.45D ? KIND_SHRINE : (k < 0.70D ? KIND_TOWER : KIND_NEST));
            this.towerH = 7 + q.nextInt(5);
        }

        this.maxR = (int) Math.ceil(radius * (1.0D + a1 + a2 + a3 + elong)) + 1;

        this.axisCos = Math.cos(fallAngle);
        this.axisSin = Math.sin(fallAngle);
        double la;
        double lb;
        double lakeDist;
        if (legacy) {
            la = 5.0D;
            lb = 4.4D;
            lakeDist = radius * 0.62D;
        } else {
            la = clamp(radius * 0.19D * (0.85D + q.nextDouble() * 0.4D), 2.2D, 8.5D);
            lb = la * (0.82D + q.nextDouble() * 0.14D);
            double edge = radiusAt(fallAngle);
            lakeDist = Math.max(4.0D, Math.min(radius * 0.62D, edge - la * 1.2D - 2.0D));
        }
        this.lakeA = la;
        this.lakeB = lb;
        this.lakeX = axisCos * lakeDist;
        this.lakeZ = axisSin * lakeDist;

        this.pillars = new int[pillarCount][2];
        this.pillarHeight = new int[pillarCount];
        this.arch = new boolean[pillarCount];

        if (!legacy && radius >= 30) {
            computePonds(q);
        }
        computeChannel(lakeDist);
        computeVine();
        if (shrineKind != KIND_NONE) {
            computeShrine();
        } else {
            shrineX = 100000;
            shrineZ = 100000;
            doorX = 0;
            doorZ = 1;
        }
        if (!legacy && styleId == IslaStyle.VOLCANICA && radius >= 22) {
            computeCrater(q);
        }
        computePillars(r);
        computeSpawns(r);
        if (!legacy && radius >= 24) {
            computeIslets(q);
        }
    }

    // ------------------------------------------------------------------ forma

    public double radiusAt(double theta) {
        return radius * (1.0D + a1 * Math.sin(f1 * theta + p1)
                + a2 * Math.sin(f2 * theta + p2)
                + a3 * Math.sin(f3 * theta + p3)
                + elong * Math.cos(2.0D * (theta - elongPhase)));
    }

    public boolean inside(int x, int z) {
        double d = Math.sqrt((double) x * x + (double) z * z);
        if (d < 1.0E-6D) {
            return true;
        }
        return d <= radiusAt(Math.atan2(z, x));
    }

    /** Distancia al centro dividida por el radio local: 0 en el centro, 1 en el borde. */
    public double frac(int x, int z) {
        double d = Math.sqrt((double) x * x + (double) z * z);
        if (d < 1.0E-6D) {
            return 0.0D;
        }
        return d / radiusAt(Math.atan2(z, x));
    }

    public boolean nearLake(int x, int z, double scale) {
        double dx = x - lakeX;
        double dz = z - lakeZ;
        double u = dx * axisCos + dz * axisSin;
        double v = -dx * axisSin + dz * axisCos;
        double wobble = 1.0D + 0.12D * Math.sin(3.0D * Math.atan2(v, u) + p1);
        double e = (u / lakeA) * (u / lakeA) + (v / lakeB) * (v / lakeB);
        double limit = scale * wobble;
        if (e <= limit * limit) {
            return true;
        }
        for (double[] pond : ponds) {
            double px = x - pond[0];
            double pz = z - pond[1];
            double lim = pond[2] * scale;
            if (px * px + pz * pz <= lim * lim) {
                return true;
            }
        }
        return false;
    }

    public boolean isChannel(int x, int z) {
        return channelSet.contains(key(x, z));
    }

    public boolean nearChannel(int x, int z) {
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (channelSet.contains(key(x + i, z + j))) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean inPlaza(int x, int z) {
        return (double) (x * x + z * z) <= plazaR * plazaR;
    }

    public boolean inShrine(int x, int z, int margin) {
        return Math.abs(x - shrineX) <= SHRINE_HALF + margin && Math.abs(z - shrineZ) <= SHRINE_HALF + margin;
    }

    public boolean nearCrater(int x, int z, double margin) {
        if (!hasCrater) {
            return false;
        }
        double dx = x - craterX;
        double dz = z - craterZ;
        double lim = CRATER_R + margin;
        return dx * dx + dz * dz <= lim * lim;
    }

    /** Zonas que se mantienen planas y sin vegetacion aleatoria. */
    public boolean isReserved(int x, int z) {
        return x * x + z * z <= flatR2 || nearLake(x, z, 1.45D) || nearChannel(x, z)
                || inShrine(x, z, 3) || nearCrater(x, z, 2.0D);
    }

    /** Desplazamiento (relativo a la superficie base) de la capa superior. */
    public int topOffset(int x, int z) {
        if (isReserved(x, z)) {
            return 0;
        }
        double d = Math.sqrt((double) x * x + (double) z * z);
        double f = frac(x, z);
        double flatR = Math.sqrt(flatR2);
        double amp = clamp((d - flatR) / 6.0D, 0.0D, 1.0D) * (1.0D - clamp((f - 0.8D) / 0.2D, 0.0D, 1.0D)) * relief;
        double n = Math.sin(x * 0.23D + p1) * Math.cos(z * 0.19D + p2) + 0.5D * Math.sin(x * 0.11D - z * 0.13D + p3);
        return Math.max(-1, (int) Math.round(amp * n));
    }

    /** Desplazamiento (negativo) de la base inferior: la isla es una lente gruesa en el centro. */
    public int bottomOffset(int x, int z) {
        double f = Math.min(1.0D, frac(x, z));
        double t = Math.pow(Math.max(0.0D, 1.0D - f * f), 0.85D);
        double n = 1.6D * Math.sin(x * 0.45D + p2) * Math.sin(z * 0.4D + p3) * (1.0D - f);
        return -2 - (int) Math.round(depth * t + n);
    }

    public double rnd(int a, int b, int c) {
        long h = seed ^ ((long) a * 0x9E3779B97F4A7C15L) ^ ((long) b * 0xC2B2AE3D27D4EB4FL) ^ ((long) c * 0x165667B19E3779F9L);
        h ^= (h >>> 33);
        h *= 0xFF51AFD7ED558CCDL;
        h ^= (h >>> 33);
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= (h >>> 33);
        return (h >>> 11) * (1.0D / (double) (1L << 53));
    }

    // ------------------------------------------------------------ construccion

    private void computePonds(Random q) {
        int want = radius >= 38 ? 2 : 1;
        for (int attempt = 0; attempt < 30 && ponds.size() < want; attempt++) {
            double ang = q.nextDouble() * Math.PI * 2.0D;
            double pr = 2.6D + q.nextDouble() * 1.6D;
            double dist = radius * (0.34D + q.nextDouble() * 0.22D);
            if (angleDiff(ang, fallAngle) < 1.1D || dist < plazaR + pr + 4.5D) {
                continue;
            }
            int x = (int) Math.round(Math.cos(ang) * dist);
            int z = (int) Math.round(Math.sin(ang) * dist);
            if (nearLake(x, z, 1.9D)) {
                continue;
            }
            boolean ok = inside(x, z);
            for (int k = 0; k < 8 && ok; k++) {
                double a = k * Math.PI / 4.0D;
                ok = inside(x + (int) Math.round(Math.cos(a) * (pr + 2.0D)), z + (int) Math.round(Math.sin(a) * (pr + 2.0D)));
            }
            for (double[] other : ponds) {
                double dx = x - other[0];
                double dz = z - other[1];
                double need = pr + other[2] + 3.0D;
                if (dx * dx + dz * dz < need * need) {
                    ok = false;
                }
            }
            if (ok) {
                ponds.add(new double[]{x, z, pr});
            }
        }
    }

    private void computeChannel(double lakeDist) {
        List<int[]> cells = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        int[] lastInside = null;
        int[] firstOutside = null;
        for (double t = lakeDist; t < radius * 1.8D; t += 0.3D) {
            int x = (int) Math.round(axisCos * t);
            int z = (int) Math.round(axisSin * t);
            if (!seen.add(key(x, z))) {
                continue;
            }
            if (inside(x, z)) {
                cells.add(new int[]{x, z});
                lastInside = new int[]{x, z};
            } else {
                firstOutside = new int[]{x, z};
                break;
            }
        }
        if (lastInside == null || firstOutside == null) {
            lastInside = new int[]{(int) Math.round(axisCos * radius * 0.8D), (int) Math.round(axisSin * radius * 0.8D)};
            firstOutside = new int[]{lastInside[0] + 2, lastInside[1]};
        }

        // la columna de agua debe quedar pegada (ortogonalmente) al ultimo bloque de agua del canal
        int[] lip = lastInside;
        int[] out = firstOutside;
        if (Math.abs(out[0] - lip[0]) + Math.abs(out[1] - lip[1]) != 1) {
            int[] c1 = {out[0], lip[1]};
            int[] c2 = {lip[0], out[1]};
            if (!inside(c1[0], c1[1])) {
                out = c1;
            } else if (!inside(c2[0], c2[1])) {
                out = c2;
            } else {
                cells.add(c1);
                lip = c1;
            }
        }
        for (int[] cell : cells) {
            channel.add(cell);
            channelSet.add(key(cell[0], cell[1]));
        }
        lipX = lip[0];
        lipZ = lip[1];
        fallX = out[0];
        fallZ = out[1];
    }

    private void computeVine() {
        double c = Math.cos(vineAngle);
        double s = Math.sin(vineAngle);
        int[] out = null;
        for (double t = radius * 0.6D; t < radius * 1.8D; t += 0.25D) {
            int x = (int) Math.round(c * t);
            int z = (int) Math.round(s * t);
            if (!inside(x, z)) {
                out = new int[]{x, z};
                break;
            }
        }
        if (out == null) {
            out = new int[]{(int) Math.round(c * radius * 1.2D), (int) Math.round(s * radius * 1.2D)};
        }
        vineX = out[0];
        vineZ = out[1];
        vineSx = c >= 0.0D ? 1 : -1;
        vineSz = s >= 0.0D ? 1 : -1;
    }

    private void computeShrine() {
        int bestX = 0;
        int bestZ = 0;
        boolean found = false;
        double minDist = pillarR + 4.0D;
        for (double f = 0.62D; f >= 0.40D && !found; f -= 0.03D) {
            int sx = (int) Math.round(Math.cos(shrineAngle) * radius * f);
            int sz = (int) Math.round(Math.sin(shrineAngle) * radius * f);
            boolean fits = true;
            for (int dx = -(SHRINE_HALF + 1); dx <= SHRINE_HALF + 1 && fits; dx += SHRINE_HALF + 1) {
                for (int dz = -(SHRINE_HALF + 1); dz <= SHRINE_HALF + 1; dz += SHRINE_HALF + 1) {
                    if (frac(sx + dx, sz + dz) > 0.86D || nearLake(sx + dx, sz + dz, 1.6D)) {
                        fits = false;
                        break;
                    }
                }
            }
            if (fits && Math.sqrt((double) sx * sx + (double) sz * sz) >= minDist) {
                bestX = sx;
                bestZ = sz;
                found = true;
            }
        }
        if (!found) {
            bestX = (int) Math.round(Math.cos(shrineAngle) * radius * 0.5D);
            bestZ = (int) Math.round(Math.sin(shrineAngle) * radius * 0.5D);
        }
        shrineX = bestX;
        shrineZ = bestZ;
        if (Math.abs(shrineX) >= Math.abs(shrineZ)) {
            doorX = shrineX > 0 ? -1 : 1;
            doorZ = 0;
        } else {
            doorX = 0;
            doorZ = shrineZ > 0 ? -1 : 1;
        }
    }

    private void computeCrater(Random q) {
        for (int attempt = 0; attempt < 30 && !hasCrater; attempt++) {
            double ang = q.nextDouble() * Math.PI * 2.0D;
            double dist = radius * (0.42D + q.nextDouble() * 0.16D);
            if (angleDiff(ang, fallAngle) < 0.9D || dist < pillarR + 4.5D) {
                continue;
            }
            int x = (int) Math.round(Math.cos(ang) * dist);
            int z = (int) Math.round(Math.sin(ang) * dist);
            boolean ok = !nearLake(x, z, 1.9D) && !nearChannel(x, z) && !inShrine(x, z, 5);
            for (int k = 0; k < 8 && ok; k++) {
                double a = k * Math.PI / 4.0D;
                ok = inside(x + (int) Math.round(Math.cos(a) * (CRATER_R + 3.0D)),
                        z + (int) Math.round(Math.sin(a) * (CRATER_R + 3.0D)));
            }
            if (ok) {
                craterX = x;
                craterZ = z;
                hasCrater = true;
            }
        }
    }

    private void computePillars(Random r) {
        for (int i = 0; i < pillarCount; i++) {
            double a = i * Math.PI * 2.0D / pillarCount + Math.PI / pillarCount;
            int x = (int) Math.round(Math.cos(a) * pillarR);
            int z = (int) Math.round(Math.sin(a) * pillarR);
            pillars[i][0] = x;
            pillars[i][1] = z;
            int h = 3 + r.nextInt(5);
            if (r.nextInt(100) < 30) {
                h = 1 + r.nextInt(3);
            }
            arch[i] = r.nextInt(100) < 65;
            if (inShrine(x, z, 2) || nearLake(x, z, 1.5D) || nearChannel(x, z) || !inside(x, z)) {
                h = 0;
            }
            pillarHeight[i] = h;
        }
    }

    private void computeSpawns(Random r) {
        int max = legacy ? 14 : clampI(radius * radius / 42, 4, 40);
        int attempts = legacy ? 300 : 800;
        for (int attempt = 0; attempt < attempts && spawns.size() < max; attempt++) {
            double a = r.nextDouble() * Math.PI * 2.0D;
            double rr = 3.0D + r.nextDouble() * (radius * 0.82D - 3.0D);
            int x = (int) Math.round(Math.cos(a) * rr);
            int z = (int) Math.round(Math.sin(a) * rr);
            if (!inside(x, z) || nearLake(x, z, 1.35D) || inShrine(x, z, 2) || nearChannel(x, z)
                    || nearCrater(x, z, 2.5D)) {
                continue;
            }
            spawns.add(new int[]{x, z});
        }
        if (shrineKind == KIND_NEST) {
            spawns.add(new int[]{shrineX - 1, shrineZ - 1});
            spawns.add(new int[]{shrineX + 1, shrineZ});
            spawns.add(new int[]{shrineX, shrineZ + 1});
        }
    }

    private void computeIslets(Random q) {
        int want = q.nextInt(4);
        if (radius >= 34 && want < 1) {
            want = 1;
        }
        for (int attempt = 0; attempt < 40 && islets.size() < want; attempt++) {
            double ang = q.nextDouble() * Math.PI * 2.0D;
            int ir = 3 + q.nextInt(3);
            double dist = radiusAt(ang) + ir + 3.0D + q.nextDouble() * 3.0D;
            double decorRoll = q.nextDouble();
            int dy = -8 + q.nextInt(15);
            int thick = 3 + ir + q.nextInt(3);
            if (angleDiff(ang, fallAngle) < 0.6D || angleDiff(ang, vineAngle) < 0.7D) {
                continue;
            }
            int x = (int) Math.round(Math.cos(ang) * dist);
            int z = (int) Math.round(Math.sin(ang) * dist);
            boolean ok = true;
            for (int[] other : islets) {
                double dx = x - other[0];
                double dz = z - other[1];
                double need = ir + other[3] + 3.0D;
                if (dx * dx + dz * dz < need * need) {
                    ok = false;
                }
            }
            if (ok) {
                int decor = decorRoll < 0.25D ? 2 : (decorRoll < 0.55D ? 1 : 0);
                islets.add(new int[]{x, z, dy, ir, thick, decor});
            }
        }
    }

    private static double angleDiff(double a, double b) {
        return Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
    }

    private static long key(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }

    private static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static int clampI(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
